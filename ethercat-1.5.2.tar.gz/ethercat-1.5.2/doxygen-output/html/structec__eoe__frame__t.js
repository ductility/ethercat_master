var structec__eoe__frame__t =
[
    [ "queue", "structec__eoe__frame__t.html#a1c6d064788e29158bd03601b481bcfa5", null ],
    [ "skb", "structec__eoe__frame__t.html#a373ee9510d98da5da3077944d5d074cb", null ]
];