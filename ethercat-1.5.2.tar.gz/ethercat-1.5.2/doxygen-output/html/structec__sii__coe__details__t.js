var structec__sii__coe__details__t =
[
    [ "enable_sdo", "structec__sii__coe__details__t.html#a13bf2bdd0c2fa9986d8d176f956f50ca", null ],
    [ "enable_sdo_info", "structec__sii__coe__details__t.html#af90ce21692e401ce0205e4e9f14a9386", null ],
    [ "enable_pdo_assign", "structec__sii__coe__details__t.html#a30ce481a3965c5bc1737918e3cbe6d63", null ],
    [ "enable_pdo_configuration", "structec__sii__coe__details__t.html#acefe917c36bc9c0fc0ff931fcbabc211", null ],
    [ "enable_upload_at_startup", "structec__sii__coe__details__t.html#a1bb6f479bf46b3113a181478f8b1fbef", null ],
    [ "enable_sdo_complete_access", "structec__sii__coe__details__t.html#a8b34817a87dbb31e79d076b67ea3d1be", null ]
];