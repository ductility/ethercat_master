var structec__rtdm__context__t =
[
    [ "user_info", "structec__rtdm__context__t.html#a062a354a243cbc0dddbfd9f440a68135", null ],
    [ "ioctl_ctx", "structec__rtdm__context__t.html#ad605852d8673c7094398ea5307d3737b", null ]
];