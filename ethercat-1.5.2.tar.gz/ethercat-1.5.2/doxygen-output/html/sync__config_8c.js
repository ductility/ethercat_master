var sync__config_8c =
[
    [ "ec_sync_config_init", "sync__config_8c.html#ab94e78860fab0b248f512d564223a32c", null ],
    [ "ec_sync_config_clear", "sync__config_8c.html#a58935740adbd4abcc2edb3c30054bc96", null ]
];