var structec__coe__emerg__msg__t =
[
    [ "data", "structec__coe__emerg__msg__t.html#a34851e07295140751d9d7edf7dea2561", null ]
];