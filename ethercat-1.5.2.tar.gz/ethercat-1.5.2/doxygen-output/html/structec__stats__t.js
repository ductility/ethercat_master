var structec__stats__t =
[
    [ "timeouts", "structec__stats__t.html#a955d4a4b543d39ef33e3be00b7035551", null ],
    [ "corrupted", "structec__stats__t.html#a05d3aa920802468a437e8518d84b5b4c", null ],
    [ "unmatched", "structec__stats__t.html#ace86973203e2ef1838f9345f9eb2d767", null ],
    [ "output_jiffies", "structec__stats__t.html#a1b5236e09088fa71c8bdc73b4f9de70a", null ]
];