var structec__cdev__t =
[
    [ "master", "structec__cdev__t.html#ad6d790982111fa9d63a1e0d1baf0828f", null ],
    [ "cdev", "structec__cdev__t.html#a5595c2c852f7a794ca343013e96e619a", null ]
];