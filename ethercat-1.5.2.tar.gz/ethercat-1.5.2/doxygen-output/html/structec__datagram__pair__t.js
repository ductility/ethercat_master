var structec__datagram__pair__t =
[
    [ "list", "structec__datagram__pair__t.html#a8b2eafeceb6565bfe2d0c2363679ba1e", null ],
    [ "domain", "structec__datagram__pair__t.html#aaaa75d1c846028cdd78be790c82a9e31", null ],
    [ "datagrams", "structec__datagram__pair__t.html#a3984a280ea726795e9402bc7363d05ed", null ],
    [ "expected_working_counter", "structec__datagram__pair__t.html#aa6e12e670f12a511f108b9cd7974f1ce", null ]
];