var structec__sync__signal__t =
[
    [ "cycle_time", "structec__sync__signal__t.html#a584e9c4963c35777cfc06838793e20e0", null ],
    [ "shift_time", "structec__sync__signal__t.html#a75c1a27b0421473e05bf737fd0d38368", null ]
];