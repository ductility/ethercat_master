var structec__fsm__soe =
[
    [ "slave", "structec__fsm__soe.html#ac70c33e8ea8a98b79d84c3ace3416180", null ],
    [ "retries", "structec__fsm__soe.html#a717e23d822ee8bca76b9b477ff078bb7", null ],
    [ "state", "structec__fsm__soe.html#a165beb536c80ee10e46908c7f2e3b7d8", null ],
    [ "datagram", "structec__fsm__soe.html#ad94b8e0cd3aeb06cc554b1405bf02436", null ],
    [ "jiffies_start", "structec__fsm__soe.html#ad9dc7d3d67af743a7181a878f23faa84", null ],
    [ "request", "structec__fsm__soe.html#add6279a51617da94d91420bb05e57a7c", null ],
    [ "offset", "structec__fsm__soe.html#a2e2bdcd1fdb5d507480e0c29a97ce7d0", null ],
    [ "fragment_size", "structec__fsm__soe.html#ae3f6c643ecacae3364064dc9f466c95a", null ]
];