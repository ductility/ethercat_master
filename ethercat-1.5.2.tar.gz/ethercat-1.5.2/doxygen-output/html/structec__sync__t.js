var structec__sync__t =
[
    [ "slave", "structec__sync__t.html#a76825f16d6c2d649740045b5a0c96a26", null ],
    [ "physical_start_address", "structec__sync__t.html#a35017ae8615f6eee4ecb5ed044501184", null ],
    [ "default_length", "structec__sync__t.html#ade13d88d878f5e87763c34b636a4c1a1", null ],
    [ "control_register", "structec__sync__t.html#aede99eccf8db60056e6deebe66501365", null ],
    [ "enable", "structec__sync__t.html#a581dfbd7e289ab43dc3f5b7f844c4776", null ],
    [ "pdos", "structec__sync__t.html#a96e5121c2fd258439b25d1a826ec5970", null ]
];