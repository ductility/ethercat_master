var structec__sync__info__t =
[
    [ "index", "structec__sync__info__t.html#a87956061ffbec80e40b2aa7a3c65791c", null ],
    [ "dir", "structec__sync__info__t.html#a30a8f40bfcbda77239378f0cef039c70", null ],
    [ "n_pdos", "structec__sync__info__t.html#a25e3f4601c01b018bef363e3f3a3d38d", null ],
    [ "pdos", "structec__sync__info__t.html#a1a9322a8f1da38ce383542374108b76d", null ],
    [ "watchdog_mode", "structec__sync__info__t.html#abeb91973efe10dd69ce8fb57135e8253", null ]
];