var ethernet_8h =
[
    [ "ec_eoe_frame_t", "structec__eoe__frame__t.html", "structec__eoe__frame__t" ],
    [ "ec_eoe", "structec__eoe.html", "structec__eoe" ],
    [ "ec_eoe_t", "ethernet_8h.html#a03b01351f25a9210938e676941427cf4", null ],
    [ "ec_eoe_init", "ethernet_8h.html#a890ed81aeeee6742971bae174623f7d9", null ],
    [ "ec_eoe_clear", "ethernet_8h.html#a2d848439972cb4dcc037a2f9bb456715", null ],
    [ "ec_eoe_run", "ethernet_8h.html#ab7ba009185c67570f4c95446cee7eb76", null ],
    [ "ec_eoe_queue", "ethernet_8h.html#a18fc60e72cbbc99eb59a0e43abdfe328", null ],
    [ "ec_eoe_is_open", "ethernet_8h.html#aac0563934b958ac04dc433e8fe442234", null ],
    [ "ec_eoe_is_idle", "ethernet_8h.html#a2c002900d42f291213e271b7196f991e", null ]
];