var structec__sdo =
[
    [ "list", "structec__sdo.html#a19e6bd6217318c1a84191ce3bc28ebca", null ],
    [ "slave", "structec__sdo.html#abaa23035a820b5eaae49b95b98ef3985", null ],
    [ "index", "structec__sdo.html#a1764ade2d1d34c8e0c8951ff4a809663", null ],
    [ "object_code", "structec__sdo.html#ad1e3b4f7b9d26d163289b7ab6b36b011", null ],
    [ "name", "structec__sdo.html#a4dae1d2cd41ce8ab4407097ed7844472", null ],
    [ "max_subindex", "structec__sdo.html#ad493bab8f7ef1179d41172bbc445c77e", null ],
    [ "entries", "structec__sdo.html#a9f7c6b8967a84ba8686f1eb851019b4f", null ]
];