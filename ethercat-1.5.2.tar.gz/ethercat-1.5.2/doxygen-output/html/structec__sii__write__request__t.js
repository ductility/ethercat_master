var structec__sii__write__request__t =
[
    [ "list", "structec__sii__write__request__t.html#a08c68d50c7e2fecfff3d1f54ede50b60", null ],
    [ "slave", "structec__sii__write__request__t.html#a1fb11a824ca776c9725157703c64a351", null ],
    [ "offset", "structec__sii__write__request__t.html#a9b70af97dacc5056389bcde6ac1cf107", null ],
    [ "nwords", "structec__sii__write__request__t.html#a98d3bd46058ea045c94f6f32d0b01d62", null ],
    [ "words", "structec__sii__write__request__t.html#a8a435488d56415ece3c1c531bf9712bf", null ],
    [ "state", "structec__sii__write__request__t.html#a4751ad577cec3bff18f540147a8e7ca0", null ]
];