var structec__domain =
[
    [ "list", "structec__domain.html#a2d15a4d54c3c1893bd3902d43380d474", null ],
    [ "master", "structec__domain.html#a58e4f4b7d54f30e58c7187268c1525c1", null ],
    [ "index", "structec__domain.html#ac341000021b5790693cc74f7687fb956", null ],
    [ "fmmu_configs", "structec__domain.html#af7578fbb9d9c493a4c086b5c9cc3796b", null ],
    [ "data_size", "structec__domain.html#a7c2dfe55da8c96a17ace9de29e8cbb95", null ],
    [ "data", "structec__domain.html#ab6ced9980be9d70c0c610cf00e44793d", null ],
    [ "data_origin", "structec__domain.html#a2ff57b73bc954e0ce90f1cee5d0a2721", null ],
    [ "logical_base_address", "structec__domain.html#a5efe0cdd408c44ad61c52952f28f14de", null ],
    [ "datagram_pairs", "structec__domain.html#a9935943271eabfa9d5c68b5c19fe3bee", null ],
    [ "working_counter", "structec__domain.html#a6f18a1d8c6b2a83acf3e5932a5f3048f", null ],
    [ "expected_working_counter", "structec__domain.html#af978a94741ca2483ce0460e34c77271d", null ],
    [ "working_counter_changes", "structec__domain.html#abe70425a9c3e701f4b561d0baac2e29c", null ],
    [ "redundancy_active", "structec__domain.html#aeb8f64931c44dc2c89521b94f54879d6", null ],
    [ "notify_jiffies", "structec__domain.html#a5d14409ef398792e134f5b4f170a9f5c", null ]
];