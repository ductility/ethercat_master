var structec__foe__request__t =
[
    [ "list", "structec__foe__request__t.html#a3934835725b006bc6268d2553234901a", null ],
    [ "buffer", "structec__foe__request__t.html#a9f6af09dc6347bb9139f488c7ca48427", null ],
    [ "buffer_size", "structec__foe__request__t.html#a5cf1b56bd0f3406f9cf36650fc5ac7aa", null ],
    [ "data_size", "structec__foe__request__t.html#aa7b6efa4a99fe568f8f53ae0b2ebc2e4", null ],
    [ "issue_timeout", "structec__foe__request__t.html#a313c264273fbc3dc6b7aa4a177dd1505", null ],
    [ "response_timeout", "structec__foe__request__t.html#a347a7ba58a6616319766bc65e2957ef9", null ],
    [ "dir", "structec__foe__request__t.html#a28940cc34e5ddb8a960cc459040bbcc9", null ],
    [ "state", "structec__foe__request__t.html#afd59d6b4eb03fe6f05a20179cef9ac5e", null ],
    [ "jiffies_start", "structec__foe__request__t.html#a3fef682f7dcd197e1fa74cf90a2e8963", null ],
    [ "jiffies_sent", "structec__foe__request__t.html#ac0d7533c6fc99ddf0a4584837a2829d3", null ],
    [ "file_name", "structec__foe__request__t.html#a9ff443ccddd8bd0492f364abb7fd4a32", null ],
    [ "result", "structec__foe__request__t.html#a3755f2ecc7d79a09afc8d567b11b7aef", null ],
    [ "error_code", "structec__foe__request__t.html#a61bb591aa99ad14d759e67c687b11d5d", null ]
];