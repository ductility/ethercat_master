var structec__fsm__change =
[
    [ "slave", "structec__fsm__change.html#ae3843c25b9fd49665931655cafc21b3d", null ],
    [ "datagram", "structec__fsm__change.html#ab273d6047105421f11b993301269dea3", null ],
    [ "retries", "structec__fsm__change.html#a00a1bc8fab1ccbed6b723bebb19ae34b", null ],
    [ "state", "structec__fsm__change.html#acd06ab4990fd4b46266a679fed6e0695", null ],
    [ "mode", "structec__fsm__change.html#a3565fb9fec03a24d1d3a66cce7e9fce3", null ],
    [ "requested_state", "structec__fsm__change.html#a64a969bd6bad475ff30870eed7f79266", null ],
    [ "old_state", "structec__fsm__change.html#a1327ecfcea3bdd858423750cf22783e6", null ],
    [ "jiffies_start", "structec__fsm__change.html#aa357cf0cae0e5b306b6f555d48dc47ba", null ],
    [ "take_time", "structec__fsm__change.html#a86dd65308e2a0e1c89a96f35d2b5672f", null ],
    [ "spontaneous_change", "structec__fsm__change.html#a67f934c317235fc5ea71ee128f6a979b", null ]
];