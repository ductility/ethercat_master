var structec__fsm__sii =
[
    [ "slave", "structec__fsm__sii.html#a8900a8deb8f7f8fa21b678bb45c49bd6", null ],
    [ "datagram", "structec__fsm__sii.html#a0b742789c074c3ebff83f0892571fd20", null ],
    [ "retries", "structec__fsm__sii.html#a1571b23ec01b79dc7287d327cc6a4812", null ],
    [ "state", "structec__fsm__sii.html#a6b2ea3e71e4ee37254a8cdab003d6ad2", null ],
    [ "word_offset", "structec__fsm__sii.html#afecb19ccde2a49881d9430c65a854880", null ],
    [ "mode", "structec__fsm__sii.html#abe104575bf34cbfb34beee82562524a7", null ],
    [ "value", "structec__fsm__sii.html#ac95eca9edba43bc2e9e6354a35f6cd77", null ],
    [ "jiffies_start", "structec__fsm__sii.html#ab7f2a8187c72c4dcd08235b1533062b5", null ],
    [ "check_once_more", "structec__fsm__sii.html#aa42a961a6e212bced0051dbf569b47c3", null ]
];