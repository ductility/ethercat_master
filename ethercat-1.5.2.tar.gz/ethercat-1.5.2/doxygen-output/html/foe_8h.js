var foe_8h =
[
    [ "ec_foe_error_t", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659", [
      [ "FOE_BUSY", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659aacad8c11589f51ab29e655b3e1f1b636", null ],
      [ "FOE_READY", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659af6ef86c554beba5260555602f7aa783d", null ],
      [ "FOE_IDLE", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a3ebc15a7b225189ffc6b8545574f7868", null ],
      [ "FOE_WC_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a43ef98e38a295df885d2276078a92bae", null ],
      [ "FOE_RECEIVE_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a622fc9421868423ac34832850e8ea7e1", null ],
      [ "FOE_PROT_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659adca69ad8fe0509935b2b73550c8396cc", null ],
      [ "FOE_NODATA_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a92cfaf513f401687840e135c583bff70", null ],
      [ "FOE_PACKETNO_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a705685af4df10e2c35bc2aa51f33f6e2", null ],
      [ "FOE_OPCODE_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a68ef05dbc34f0a242d4c1850776a331a", null ],
      [ "FOE_TIMEOUT_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659aafb61e94e694f92fb200976a5c8545d9", null ],
      [ "FOE_SEND_RX_DATA_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a7e4d06a6136f1233195d7513913396ed", null ],
      [ "FOE_RX_DATA_ACK_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a4232c0480c23c085cdb159b7f1463d1e", null ],
      [ "FOE_ACK_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a9b953b8276c951de27df080f5b2b9751", null ],
      [ "FOE_MBOX_FETCH_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659ac76f35a7c145a9178217692e87f64811", null ],
      [ "FOE_READ_NODATA_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a4dc0872a7ce485c75a74fc161b5080cd", null ],
      [ "FOE_MBOX_PROT_ERROR", "foe_8h.html#a1a3752c2c35892afeaf65cac5615c659a5bceb1cbe5096a97510b5f4f66121908", null ]
    ] ]
];