var group__TTYInterface =
[
    [ "ec_tty_operations_t", "structec__tty__operations__t.html", [
      [ "cflag_changed", "structec__tty__operations__t.html#ae34fae0b4916fbc5d016c7c0fad95a47", null ]
    ] ],
    [ "ec_tty_t", "group__TTYInterface.html#gabf4bbf300a5c451d7fe82b65e17f097d", null ],
    [ "ectty_create", "group__TTYInterface.html#ga64244c8ea384d633c3f8edfadeecffb3", null ],
    [ "ectty_free", "group__TTYInterface.html#ga03d764370f5d76bec71412ea1124a156", null ],
    [ "ectty_tx_data", "group__TTYInterface.html#ga71580e6fbab0aa678073c139bf516dae", null ],
    [ "ectty_rx_data", "group__TTYInterface.html#ga9d2e53ca7492e1a71a26cbbc7d51af52", null ]
];