var structec__slave__port__link__t =
[
    [ "link_up", "structec__slave__port__link__t.html#a91706295ab6fa0761233b12a7e35d016", null ],
    [ "loop_closed", "structec__slave__port__link__t.html#aefb5e82418479aa5f9043c9fe6503655", null ],
    [ "signal_detected", "structec__slave__port__link__t.html#a4ee187234a71d54517327aa02f076513", null ]
];