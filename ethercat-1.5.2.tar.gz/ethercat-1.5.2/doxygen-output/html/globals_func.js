var globals_func =
[
    [ "e", "globals_func.html", null ],
    [ "s", "globals_func_s.html", null ]
];