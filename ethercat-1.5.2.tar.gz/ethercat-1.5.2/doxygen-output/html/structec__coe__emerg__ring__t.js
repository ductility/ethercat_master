var structec__coe__emerg__ring__t =
[
    [ "sc", "structec__coe__emerg__ring__t.html#a797c7475bf92dd29e31802e6501a8c47", null ],
    [ "msgs", "structec__coe__emerg__ring__t.html#af505c9c347ce9a49448a36252dde0f45", null ],
    [ "size", "structec__coe__emerg__ring__t.html#a26777c2390fb1a329e0866f7954c447b", null ],
    [ "read_index", "structec__coe__emerg__ring__t.html#a80d30a36f0afa019ff6c30b0b9bb0cbe", null ],
    [ "write_index", "structec__coe__emerg__ring__t.html#ad4f4b63ee5489b89404912b1780fcf8a", null ],
    [ "overruns", "structec__coe__emerg__ring__t.html#a108ec818f8a5411a67fd78731b1e6c9b", null ]
];