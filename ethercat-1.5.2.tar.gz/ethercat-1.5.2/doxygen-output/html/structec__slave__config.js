var structec__slave__config =
[
    [ "list", "structec__slave__config.html#a52b1f382ad8f4272ece7870347dc9118", null ],
    [ "master", "structec__slave__config.html#ac5bef8d37047b658df7b56f7ebdbfecb", null ],
    [ "alias", "structec__slave__config.html#a62dbce2ad4cf9367261c293534d0730c", null ],
    [ "position", "structec__slave__config.html#adf5176b65d59852f91125066b6bf3f07", null ],
    [ "vendor_id", "structec__slave__config.html#ad561239255f4392e34fb12e0327063e0", null ],
    [ "product_code", "structec__slave__config.html#a11dfa0af49e66d7b44f2b78d122e1040", null ],
    [ "watchdog_divider", "structec__slave__config.html#aaa1db6b3136fa60412cbf8d1302c48e9", null ],
    [ "watchdog_intervals", "structec__slave__config.html#a51e0bd197191abd7a46fd3206575eccb", null ],
    [ "slave", "structec__slave__config.html#ad1c2b1916ca2208c52cf0acbf6f1a8c7", null ],
    [ "sync_configs", "structec__slave__config.html#a28bf292a581f2af8696f41fa333ba0f3", null ],
    [ "fmmu_configs", "structec__slave__config.html#a87548f86b5a467a0d2da312571bac4c0", null ],
    [ "used_fmmus", "structec__slave__config.html#ab34b5531b56f3bb35ea0647f3aa8345a", null ],
    [ "dc_assign_activate", "structec__slave__config.html#a444000aa859f4830053b65518fc65233", null ],
    [ "dc_sync", "structec__slave__config.html#a947ad2e8f2573df6655965524575c5b8", null ],
    [ "sdo_configs", "structec__slave__config.html#aa980b60539d3818999fe9ba116851e1c", null ],
    [ "sdo_requests", "structec__slave__config.html#a51461cce3b38ac55be3e046c5e93a932", null ],
    [ "voe_handlers", "structec__slave__config.html#afab81a75365c94fde03e15446fe7cc9e", null ],
    [ "reg_requests", "structec__slave__config.html#a391b64268ec07ce78e7aa50c9641e436", null ],
    [ "soe_configs", "structec__slave__config.html#a9bfab1eba98284fcaa21079ea1700188", null ],
    [ "emerg_ring", "structec__slave__config.html#a8a43523dca6d68508d858813f3d497a9", null ]
];