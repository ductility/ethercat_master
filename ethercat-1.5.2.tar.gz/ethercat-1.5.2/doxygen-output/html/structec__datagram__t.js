var structec__datagram__t =
[
    [ "queue", "structec__datagram__t.html#a6e6acbb9301ecc6f382740eae531f00a", null ],
    [ "sent", "structec__datagram__t.html#aa1ff1596b3e36d19123be609dbf3de46", null ],
    [ "device_index", "structec__datagram__t.html#a9804c4ebdbd3e7ff5b55bfe3aa33bbef", null ],
    [ "type", "structec__datagram__t.html#a5c19753e2f2a239f3496cde3f9c1ee53", null ],
    [ "address", "structec__datagram__t.html#acbe5cfc2b01e0ec6cb720b3dc99c4027", null ],
    [ "data", "structec__datagram__t.html#ae7471d08444f2bc780532e9268859296", null ],
    [ "data_origin", "structec__datagram__t.html#ae8d52c6dc3ef92d165d9d14cd9c3d593", null ],
    [ "mem_size", "structec__datagram__t.html#a038f0d3706ceb82a71a87644bb5cb987", null ],
    [ "data_size", "structec__datagram__t.html#a2bdc1dfd68576466bfe3d276b9322959", null ],
    [ "index", "structec__datagram__t.html#a76cb4206efa88c4084db0b99c802d5b9", null ],
    [ "working_counter", "structec__datagram__t.html#a1eeebb1d33d0dbf47498dd78a966977d", null ],
    [ "state", "structec__datagram__t.html#a90d55e568be4b8464e9725c105d6c4b0", null ],
    [ "jiffies_sent", "structec__datagram__t.html#a640ba704d00d50c33e930b6c641b55d7", null ],
    [ "jiffies_received", "structec__datagram__t.html#a3a643445750ee67fa83d182eb720380e", null ],
    [ "skip_count", "structec__datagram__t.html#af7007d254b40111c064caaac6f9c4f81", null ],
    [ "stats_output_jiffies", "structec__datagram__t.html#a9a6c9216d340b19a47e802ce89fbb269", null ],
    [ "name", "structec__datagram__t.html#af2690854e7fb1c410aa37a1ed225836d", null ]
];