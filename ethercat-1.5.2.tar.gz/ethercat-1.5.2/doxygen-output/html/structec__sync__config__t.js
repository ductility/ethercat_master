var structec__sync__config__t =
[
    [ "dir", "structec__sync__config__t.html#a24246e2777a46c8aa69dcfbe6a32e4c7", null ],
    [ "watchdog_mode", "structec__sync__config__t.html#a83c2bcdf7c5a9e6541b5f47c13a4d46d", null ],
    [ "pdos", "structec__sync__config__t.html#ae70642198065ad0381dacdfa21fcebaa", null ]
];