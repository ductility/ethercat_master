var structec__voe__handler =
[
    [ "list", "structec__voe__handler.html#ab078e6fbc73c7bb4f7cb465b6c4abfa3", null ],
    [ "config", "structec__voe__handler.html#a0d54cd53df6b6aa0d3f5d0bdd4d61686", null ],
    [ "datagram", "structec__voe__handler.html#a22dc8e8a089f2a9df8336828d4ddcbe6", null ],
    [ "vendor_id", "structec__voe__handler.html#a2c8f52c786041ad0600c3d3b84db48e7", null ],
    [ "vendor_type", "structec__voe__handler.html#aa0f8674c035659f9f2850045ed641139", null ],
    [ "data_size", "structec__voe__handler.html#a8f7609a3c03d2eab155ea2d24c4353e2", null ],
    [ "dir", "structec__voe__handler.html#a4930b843f8706117298fd50362514117", null ],
    [ "state", "structec__voe__handler.html#a214b9c6c45ae1d97da28b33f48fc9625", null ],
    [ "request_state", "structec__voe__handler.html#a08b2653c2e110c29f17b28dce2094c69", null ],
    [ "retries", "structec__voe__handler.html#a94b591afc9239d7da95ce47108211048", null ],
    [ "jiffies_start", "structec__voe__handler.html#a394c2e7f86802ae0c78a1d7f5a762cc5", null ]
];