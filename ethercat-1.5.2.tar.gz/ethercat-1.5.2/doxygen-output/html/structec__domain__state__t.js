var structec__domain__state__t =
[
    [ "working_counter", "structec__domain__state__t.html#a6246d096eb6a38af58b454e40fa89b59", null ],
    [ "wc_state", "structec__domain__state__t.html#a51f6fe3b5da92cd4d5851a324415f9d7", null ],
    [ "redundancy_active", "structec__domain__state__t.html#a8a0852a6265bd22b1178934542273714", null ]
];