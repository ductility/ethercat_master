var structec__sdo__entry__t =
[
    [ "list", "structec__sdo__entry__t.html#a7ac0567e0a3b260803d3de36ddbc7a63", null ],
    [ "sdo", "structec__sdo__entry__t.html#a191cd495d9a5b0b13af072f704b88733", null ],
    [ "subindex", "structec__sdo__entry__t.html#a7411aa63d3e57ac816ecfbabdc9926c8", null ],
    [ "data_type", "structec__sdo__entry__t.html#af4acb6fdd5f5e28da087056cc175ee5f", null ],
    [ "bit_length", "structec__sdo__entry__t.html#af08992d35099a3fd0c28122ade246476", null ],
    [ "read_access", "structec__sdo__entry__t.html#ac352ad9037ebdf7ea4743bd27a4f6a3a", null ],
    [ "write_access", "structec__sdo__entry__t.html#a06615e177748b777d53f333c3790614d", null ],
    [ "description", "structec__sdo__entry__t.html#ad145c04a675a87b012e0b2666b8b9453", null ]
];