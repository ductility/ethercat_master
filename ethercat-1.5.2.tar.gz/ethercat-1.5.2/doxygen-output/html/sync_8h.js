var sync_8h =
[
    [ "ec_sync_t", "structec__sync__t.html", "structec__sync__t" ],
    [ "ec_sync_init", "sync_8h.html#a29f4dd145455097fef860bdd3c5a8de9", null ],
    [ "ec_sync_init_copy", "sync_8h.html#a31f2b633260698acdce16b652d72809b", null ],
    [ "ec_sync_clear", "sync_8h.html#af97d18e6309cc3ea675995287713f8f0", null ],
    [ "ec_sync_page", "sync_8h.html#a8d1b5ce1731d355b658857f7696edba5", null ],
    [ "ec_sync_add_pdo", "sync_8h.html#a816771d389f3c39e39cfb4cf35d415fb", null ],
    [ "ec_sync_default_direction", "sync_8h.html#acb0bd9718b40240f920103463bd36ed1", null ]
];