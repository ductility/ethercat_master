var debug_8h =
[
    [ "ec_debug_t", "structec__debug__t.html", "structec__debug__t" ],
    [ "ec_debug_init", "debug_8h.html#aa8debb37c58f6813ddefa8233095f496", null ],
    [ "ec_debug_clear", "debug_8h.html#aaf7590df1f37cbc094a03b6dd339a007", null ],
    [ "ec_debug_register", "debug_8h.html#a1d9b504f3765f22ec81c6e332f542add", null ],
    [ "ec_debug_unregister", "debug_8h.html#aed729c6112e274fb57539f57f0101c59", null ],
    [ "ec_debug_send", "debug_8h.html#a69e2cddd7db5ff1ac8b3e1896e7cc862", null ]
];