var structec__slave__config__state__t =
[
    [ "online", "structec__slave__config__state__t.html#a9e2af2cf43358d7abd1fdd04c293493f", null ],
    [ "operational", "structec__slave__config__state__t.html#aaadc9c8a1a5ee8b810ceaeed25723e61", null ],
    [ "al_state", "structec__slave__config__state__t.html#ae14213eb8fa0145ecf1250e46ff7c4af", null ]
];