var structec__sdo__request =
[
    [ "list", "structec__sdo__request.html#a80c68878d98d613513a0b985be43198e", null ],
    [ "index", "structec__sdo__request.html#ad8ef54b4c7495a17c81eabff59e079fd", null ],
    [ "subindex", "structec__sdo__request.html#af3b7a335ce659260bed0d04f90ba9e4a", null ],
    [ "data", "structec__sdo__request.html#aa1f9c68c95c5fde23ed0807abf884b08", null ],
    [ "mem_size", "structec__sdo__request.html#a6275d28bba5bc2a428915b717fe425e5", null ],
    [ "data_size", "structec__sdo__request.html#a9a094314f738ed0fdf4b46f4bd37dfe9", null ],
    [ "complete_access", "structec__sdo__request.html#a98a6142382d920ac06195dd6b6de2990", null ],
    [ "issue_timeout", "structec__sdo__request.html#a042249b5e1776a0c0b6fc3003ef939a2", null ],
    [ "response_timeout", "structec__sdo__request.html#a0282ca505cf8acbbe9ecbbd1999967a9", null ],
    [ "dir", "structec__sdo__request.html#aaccb8ada520d7948b4f61653df6e871f", null ],
    [ "state", "structec__sdo__request.html#a0c50e10b80720d00f11863e76ecc1755", null ],
    [ "jiffies_start", "structec__sdo__request.html#aa5be223c362a630833451bd57471a05f", null ],
    [ "jiffies_sent", "structec__sdo__request.html#ad5d35e78085bce7e20a02753024e5822", null ],
    [ "errno", "structec__sdo__request.html#a1119ddcb79a3deed62e3890481109030", null ],
    [ "abort_code", "structec__sdo__request.html#aaa992ddb3f070824088161dffb347b3e", null ]
];