var structec__master__link__state__t =
[
    [ "slaves_responding", "structec__master__link__state__t.html#af901790b400db653a2fd739275142a0e", null ],
    [ "al_states", "structec__master__link__state__t.html#a917ac210b8e3d193b845ce6f7fdc852a", null ],
    [ "link_up", "structec__master__link__state__t.html#a6c076febd20049f7764d5a3bb8409797", null ]
];