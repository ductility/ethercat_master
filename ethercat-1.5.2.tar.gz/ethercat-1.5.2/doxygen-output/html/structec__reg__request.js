var structec__reg__request =
[
    [ "list", "structec__reg__request.html#a5b7e2c24fe669f62e8d325a3537a1aec", null ],
    [ "mem_size", "structec__reg__request.html#a47f808dbe3e2c0eb1931cf5215d5743f", null ],
    [ "data", "structec__reg__request.html#a55590fb9ebef4fad289a981e5e798f29", null ],
    [ "dir", "structec__reg__request.html#ac9e44c1d65dd892c66d1a4f2a4427e48", null ],
    [ "address", "structec__reg__request.html#aa6f44f4a9851e291726cbc92f7c099fa", null ],
    [ "transfer_size", "structec__reg__request.html#ae8a1e21e4dfa24c3c0878649f33f4de9", null ],
    [ "state", "structec__reg__request.html#adfba6eddfd79740eae02362347093120", null ]
];