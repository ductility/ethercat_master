var device_8h =
[
    [ "ec_device", "structec__device.html", "structec__device" ],
    [ "EC_TX_RING_SIZE", "device_8h.html#a8e81effb90ab4150ac1fe4114e7775f0", null ],
    [ "ec_device_init", "device_8h.html#a02288d2a8148ced6479c1285f9dc2bd1", null ],
    [ "ec_device_clear", "device_8h.html#a3099aa0e5bfa03897b85f4b542108d87", null ],
    [ "ec_device_attach", "device_8h.html#a7f14ad3873acec6c4aab27a403b86e2f", null ],
    [ "ec_device_detach", "device_8h.html#a6aa86617de7ed991048e151847683a01", null ],
    [ "ec_device_open", "device_8h.html#abddc8be76e9422963c7814777bf80525", null ],
    [ "ec_device_close", "device_8h.html#afb0366cde94e727915b7bc0edd82e9d4", null ],
    [ "ec_device_poll", "device_8h.html#ae9ba13e6b8f14f6633250f176e82bec2", null ],
    [ "ec_device_tx_data", "device_8h.html#a5f9614c819d9e94aaea708f3351e2826", null ],
    [ "ec_device_send", "device_8h.html#acbce72d98a923245aca830dd82d2b36f", null ],
    [ "ec_device_clear_stats", "device_8h.html#a2889ce889e3a481040666349d4220829", null ],
    [ "ec_device_update_stats", "device_8h.html#a487e82c3004aafd09d2a2b993960ee60", null ]
];