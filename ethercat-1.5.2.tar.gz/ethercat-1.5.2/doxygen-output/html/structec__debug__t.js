var structec__debug__t =
[
    [ "device", "structec__debug__t.html#ab18ba1d3de75e73ab1d89315240b615d", null ],
    [ "dev", "structec__debug__t.html#a9c741cbedd076599ac719146bb3bdc7d", null ],
    [ "stats", "structec__debug__t.html#af6b70564444854f7f362fe5902e9dc34", null ],
    [ "registered", "structec__debug__t.html#afcecd6a1efb040b7b9740d6c0c48f497", null ],
    [ "opened", "structec__debug__t.html#ac4b768dfed6808c7c0ced1de2a22aba1", null ]
];