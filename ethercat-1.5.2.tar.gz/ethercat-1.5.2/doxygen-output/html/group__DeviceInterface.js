var group__DeviceInterface =
[
    [ "ecdev_withdraw", "group__DeviceInterface.html#ga3934f8a07aa394d558147d790fc60a8b", null ],
    [ "ecdev_open", "group__DeviceInterface.html#ga34eceaecfe6ab4fe8f0ecde1a3b311c4", null ],
    [ "ecdev_close", "group__DeviceInterface.html#ga0a6b26b2397aa49cc82915a12b8cc854", null ],
    [ "ecdev_receive", "group__DeviceInterface.html#gaf02497a3d6bb0e43dcefc1802f8666a5", null ],
    [ "ecdev_set_link", "group__DeviceInterface.html#gac1d0e31b8b60ad4e94c03148aac88499", null ],
    [ "ecdev_get_link", "group__DeviceInterface.html#gaa31bc8d955fea01e8430105c61064589", null ],
    [ "ecdev_offer", "group__DeviceInterface.html#ga522b0264934a68d51cc5b67f2c76ef30", null ]
];