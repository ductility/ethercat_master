var structec__slave__port__t =
[
    [ "desc", "structec__slave__port__t.html#ae10a313d7421e3b4b7924c295075fc9c", null ],
    [ "link", "structec__slave__port__t.html#ad29b2a093c816ae85986cf5fb9e9d6dd", null ],
    [ "next_slave", "structec__slave__port__t.html#aa3ffc650817b6ca241bae9a9232f055d", null ],
    [ "receive_time", "structec__slave__port__t.html#a4e7c3832a518186c4f1a5bc32a192eb9", null ],
    [ "delay_to_next_dc", "structec__slave__port__t.html#ad9c8ad9fc7ebd5681eb72951b1716cc5", null ]
];