var sync_8c =
[
    [ "ec_sync_init", "sync_8c.html#ae554464367e3ca0d6c2c402ee52461de", null ],
    [ "ec_sync_init_copy", "sync_8c.html#a05bfac9d6981a210919a1bed7aa10090", null ],
    [ "ec_sync_clear", "sync_8c.html#ad78623bc3b479121c5fa77acacd0c823", null ],
    [ "ec_sync_page", "sync_8c.html#addb7fcc84fa000b0b41f4a2801977b21", null ],
    [ "ec_sync_add_pdo", "sync_8c.html#a5cf8d891a77f09cc5dbb820b08bca55c", null ],
    [ "ec_sync_default_direction", "sync_8c.html#af820aa0417e581742c1ac9b65231c9da", null ]
];