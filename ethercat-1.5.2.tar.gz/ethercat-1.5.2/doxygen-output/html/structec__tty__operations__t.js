var structec__tty__operations__t =
[
    [ "cflag_changed", "structec__tty__operations__t.html#ae34fae0b4916fbc5d016c7c0fad95a47", null ]
];