var debug_8c =
[
    [ "ec_dbgdev_open", "debug_8c.html#a11a1c64e15248046846431990839c0f4", null ],
    [ "ec_dbgdev_stop", "debug_8c.html#a59052897d8dbe64aba431cc31ba628a9", null ],
    [ "ec_dbgdev_tx", "debug_8c.html#a3930f635baeaee86e93bd625b3543f2e", null ],
    [ "ec_dbgdev_stats", "debug_8c.html#ab8061a6af8b6ec3067b2c171fbae47bf", null ],
    [ "ec_debug_init", "debug_8c.html#ab4a40ce6bb6a66bd034790c3a7985c80", null ],
    [ "ec_debug_clear", "debug_8c.html#a1711152b73dc97bc81a9e9aae4b8a263", null ],
    [ "ec_debug_register", "debug_8c.html#a683a1dd06041ed934990c736ab3267a9", null ],
    [ "ec_debug_unregister", "debug_8c.html#a488b3c97e9786a33f2372180de561591", null ],
    [ "ec_debug_send", "debug_8c.html#af11807b9c95c1c4f05aa0cd5a672a560", null ],
    [ "ec_dbg_netdev_ops", "debug_8c.html#a1049a945f6a46b9a8a8ab4684958d59f", null ]
];