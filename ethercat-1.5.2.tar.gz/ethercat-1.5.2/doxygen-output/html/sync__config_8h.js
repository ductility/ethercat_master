var sync__config_8h =
[
    [ "ec_sync_config_t", "structec__sync__config__t.html", "structec__sync__config__t" ],
    [ "ec_sync_config_init", "sync__config_8h.html#a7a8aef074c9e63236438779f47342406", null ],
    [ "ec_sync_config_clear", "sync__config_8h.html#aa601ea25957e293659f5ab2512beeab9", null ]
];